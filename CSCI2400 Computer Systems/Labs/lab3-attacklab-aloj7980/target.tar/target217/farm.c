/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_476(unsigned *p)
{
    *p = 3066269784U;
}

void setval_312(unsigned *p)
{
    *p = 2428995912U;
}

void setval_378(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_294()
{
    return 2421691439U;
}

void setval_300(unsigned *p)
{
    *p = 2425393368U;
}

unsigned addval_406(unsigned x)
{
    return x + 2496104776U;
}

void setval_425(unsigned *p)
{
    *p = 2429000008U;
}

unsigned getval_395()
{
    return 2425444430U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_355(unsigned *p)
{
    *p = 2425670281U;
}

void setval_398(unsigned *p)
{
    *p = 3767076996U;
}

unsigned addval_212(unsigned x)
{
    return x + 3269495112U;
}

unsigned getval_179()
{
    return 4056140424U;
}

void setval_388(unsigned *p)
{
    *p = 3372799625U;
}

void setval_499(unsigned *p)
{
    *p = 3284830234U;
}

unsigned getval_160()
{
    return 3599324435U;
}

unsigned addval_328(unsigned x)
{
    return x + 3229925773U;
}

void setval_140(unsigned *p)
{
    *p = 2445527688U;
}

unsigned addval_409(unsigned x)
{
    return x + 3247491721U;
}

unsigned addval_351(unsigned x)
{
    return x + 2430635336U;
}

void setval_496(unsigned *p)
{
    *p = 3281046153U;
}

unsigned addval_441(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_362()
{
    return 3238607986U;
}

void setval_234(unsigned *p)
{
    *p = 3526416009U;
}

unsigned addval_452(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_472()
{
    return 3381974665U;
}

unsigned addval_218(unsigned x)
{
    return x + 3524837769U;
}

void setval_205(unsigned *p)
{
    *p = 3380926081U;
}

unsigned addval_366(unsigned x)
{
    return x + 2497743176U;
}

void setval_313(unsigned *p)
{
    *p = 3223377417U;
}

void setval_381(unsigned *p)
{
    *p = 3281049289U;
}

unsigned addval_434(unsigned x)
{
    return x + 3269495112U;
}

unsigned addval_125(unsigned x)
{
    return x + 3525886345U;
}

unsigned addval_123(unsigned x)
{
    return x + 3281043849U;
}

void setval_364(unsigned *p)
{
    *p = 3281043849U;
}

unsigned getval_209()
{
    return 3531917953U;
}

unsigned addval_403(unsigned x)
{
    return x + 3523791497U;
}

unsigned addval_400(unsigned x)
{
    return x + 3222847881U;
}

unsigned addval_151(unsigned x)
{
    return x + 3264272009U;
}

unsigned addval_374(unsigned x)
{
    return x + 3229925833U;
}

void setval_346(unsigned *p)
{
    *p = 3286272330U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
